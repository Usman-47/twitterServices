const Invoice = require("../../model/invoiceModel");
const mongoose = require("mongoose");

const GetOneInvoicePoolController = async (req, res) => {
  const { id } = req.params;
  try {
    //
    const invoiceFound = await Invoice.find(
      {
        "pool._id": mongoose.Types.ObjectId(id),
      },
      { "pool.$": 1 }
    );
    if (!invoiceFound) {
      return res.status(404).send({ msg: "No invoice Found", type: "error" });
    }
    res.send({ invoiceFound, msg: "invoice available", type: "success" });
  } catch (e) {
    console.log(e.message, " err-in GetOneInvoiceController");
    res.status(500).send({ msg: e.message, type: "failed" });
  }
};

module.exports = GetOneInvoicePoolController;

const Invoice = require("../../model/invoiceModel");

const GetAllInvoiceController = async (req, res) => {
  try {
    //
    const invoicesFound = await Invoice.find().populate("invoiceCreater");
    if (!invoicesFound) {
      return res.status(404).send({ msg: "No invoice Found", type: "error" });
    }
    res.send({ invoicesFound, msg: "invoices available", type: "success" });
  } catch (e) {
    console.log(e.message, " err-in GetAllInvoiceController");
    res.status(500).send({ msg: e.message, type: "failed" });
  }
};

module.exports = GetAllInvoiceController;

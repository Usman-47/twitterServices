// const puppeteer = require("puppeteer");

// const generatePdfFunc = async (id) => {
//   try {

//   } catch (e) {
//     console.log(e.message, " err- generatePdfFunc");
//   }
// };

// module.exports = generatePdfFunc;

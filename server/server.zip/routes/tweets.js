var Twitter = require("twitter");
const fetch = require("node-fetch");
const express = require("express");

var router = express.Router();

var client = new Twitter({
  consumer_key: "RFOfHpzgRWfAY948sHhqo29Mj",
  consumer_secret: "nVuCU2AxyjMfoWUInOTQPMvxL380RPt7GlEbd8alT6LEDvslP1",
  bearer_token:
    "AAAAAAAAAAAAAAAAAAAAAL8mewEAAAAAnHIP91XDE9qKVKgfxp965JIWGS8%3DoMa2gr0bFcJIybuikactolqiC94TqgrgidlU8Z4zqNS3U110Pr",
  timeout_ms: 60 * 1000, // optional HTTP request timeout to apply to all requests.
  strictSSL: true, // optional - requires SSL certificates to be valid.
});

router.get("/getUserTweets", async function (req, res) {
  try {
    var params = { screen_name: "FaucetRinkeby1" };
    client.get(
      "statuses/user_timeline",
      params,
      function (error, tweets, response) {
        if (!error) {
          return res.send(tweets);
        }
      }
    );
  } catch (error) {
    console.log(error);
  }
});

router.get("/getUserIdFromName/:username", async function (req, res) {
  const headers = {
    Authorization:
      "Bearer AAAAAAAAAAAAAAAAAAAAAL8mewEAAAAAnHIP91XDE9qKVKgfxp965JIWGS8%3DoMa2gr0bFcJIybuikactolqiC94TqgrgidlU8Z4zqNS3U110Pr",
  };
  fetch(
    `https://api.twitter.com/2/users/by?usernames=${req.params.username}&user.fields=username`,
    { headers }
  )
    .then((response) => response.json())
    .then((data) => {
      return res.send(data);
    });

  // fetch(
  //     "https://api.twitter.com/2/users/by?usernames=FaucetRinkeby1&user.fields=username",
  //     { headers }
  //   )
  //     .then((response) => response.json())
  //     .then((data) => {
  //       console.log(data, "data");
  //     });
});

router.get("/getUserMentions/:userId", async (req, res) => {
  try {
    const headers = {
      Authorization:
        "Bearer AAAAAAAAAAAAAAAAAAAAAL8mewEAAAAAnHIP91XDE9qKVKgfxp965JIWGS8%3DoMa2gr0bFcJIybuikactolqiC94TqgrgidlU8Z4zqNS3U110Pr",
    };

    fetch(
      `https://api.twitter.com/2/users/${req.params.userId}/mentions?expansions=author_id&user.fields=name&tweet.fields=created_at`,
      {
        headers,
      }
    )
      .then((response) => response.json())
      .then((data) => {
        return res.send(data);
      });

    // var params = { screen_name: "FaucetRinkeby1" };
    // client.get(
    //   "statuses/mentions_timeline",
    //   params,
    //   function (error, tweets, response) {
    //     if (!error) {
    //       console.log(tweets);
    //     }
    //   }
    // );
  } catch (error) {}
});

router.get("/getUserFollowers/:userId", async (req, res) => {
  try {
    const headers = {
      Authorization:
        "Bearer AAAAAAAAAAAAAAAAAAAAAL8mewEAAAAAnHIP91XDE9qKVKgfxp965JIWGS8%3DoMa2gr0bFcJIybuikactolqiC94TqgrgidlU8Z4zqNS3U110Pr",
    };

    fetch(`https://api.twitter.com/2/users/${req.params.userId}/followers`, {
      headers,
    })
      .then((response) => response.json())
      .then((data) => {
        return res.send(data);
      });
  } catch (error) {}
});

router.get("/getTweetById/:tweetId", async (req, res) => {
  try {
    const headers = {
      Authorization:
        "Bearer AAAAAAAAAAAAAAAAAAAAAL8mewEAAAAAnHIP91XDE9qKVKgfxp965JIWGS8%3DoMa2gr0bFcJIybuikactolqiC94TqgrgidlU8Z4zqNS3U110Pr",
    };

    fetch(
      `https://api.twitter.com/2/tweets/${req.params.tweetId}?expansions=author_id&user.fields=name&tweet.fields=created_at`,
      {
        headers,
      }
    )
      .then((response) => response.json())
      .then((data) => {
        return res.send(data);
      });
  } catch (error) {}
});

router.get("/getTweetliked/:tweetId", async (req, res) => {
  try {
    const headers = {
      Authorization:
        "Bearer AAAAAAAAAAAAAAAAAAAAAL8mewEAAAAAnHIP91XDE9qKVKgfxp965JIWGS8%3DoMa2gr0bFcJIybuikactolqiC94TqgrgidlU8Z4zqNS3U110Pr",
    };

    fetch(
      `https://api.twitter.com/2/tweets/${req.params.tweetId}/liking_users`,
      {
        headers,
      }
    )
      .then((response) => response.json())
      .then((data) => {
        return res.send(data);
      });
  } catch (error) {}
});

router.get("/getRetweets/:tweetId", async (req, res) => {
  try {
    const headers = {
      Authorization:
        "Bearer AAAAAAAAAAAAAAAAAAAAAL8mewEAAAAAnHIP91XDE9qKVKgfxp965JIWGS8%3DoMa2gr0bFcJIybuikactolqiC94TqgrgidlU8Z4zqNS3U110Pr",
    };

    fetch(
      `https://api.twitter.com/2/tweets/${req.params.tweetId}/retweeted_by`,
      {
        headers,
      }
    )
      .then((response) => response.json())
      .then((data) => {
        return res.send(data);
      });
  } catch (error) {}
});

router.get("/getQuotedTweetsByTweetId/:tweetId", async (req, res) => {
  try {
    const headers = {
      Authorization:
        "Bearer AAAAAAAAAAAAAAAAAAAAAL8mewEAAAAAnHIP91XDE9qKVKgfxp965JIWGS8%3DoMa2gr0bFcJIybuikactolqiC94TqgrgidlU8Z4zqNS3U110Pr",
    };

    fetch(
      `https://api.twitter.com/2/tweets/${req.params.tweetId}/quote_tweets?expansions=author_id&user.fields=name`,
      {
        headers,
      }
    )
      .then((response) => response.json())
      .then((data) => {
        return res.send(data);
      });
  } catch (error) {}
});

module.exports = router;

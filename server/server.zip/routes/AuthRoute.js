const { signToken } = require("../util/tokenFunc");

const passport = require("passport");
const mongoose = require("mongoose");
const User = require("../model/userModel");

module.exports = (app) => {
  app.get("/auth/twitter", passport.authenticate("twitter"));
  app.get(
    "/oauth/callback/twitter.com",
    passport.authenticate("twitter"),
    (req, res) => {
      res.redirect("https://sols.game/");
    }
  );

  app.get("/api/logout", (req, res) => {
    req.logOut();
    res.redirect("https://sols.game/");
  });
  app.get("/api/current_user", (req, res) => {
    if (req.user) {
      const tokenPayload = {
        name: req.user.displayName,
        email: req.user.isVerified,
        publicKey: req.user.publicKey,
        id: req.user._id,
        role: req.user.role,
      };
      const token = signToken(tokenPayload);

      if (req.user.rewardStatus) {
        res.send({
          token,
          msg: `Welcome ${req.user.displayName}`,
          type: "success",
          isVerified: req.user.isVerified,
          role: req.user.role,
          id: req.user.twitterId,
          userName: req.user.userName,
          twitterId: req.user.twitterId,
          rewardStatus: req.user.rewardStatus,
        });
      } else {
        res.send({
          token,
          msg: `Welcome ${req.user.displayName}`,
          type: "success",
          isVerified: req.user.isVerified,
          role: req.user.role,
          id: req.user.twitterId,
          userName: req.user.userName,
          twitterId: req.user.twitterId,
        });
      }
    } else {
      res.send(req.user);
    }
  });
  app.patch("/api/addUserWalletPublicKey", async (req, res) => {
    try {
      const existingUser = await User.findOne({
        publicKey: req.body.publicKey,
      });
      if (!existingUser) {
        let user = await User.findOneAndUpdate(
          {
            twitterId: req.body.twitterId,
          },
          { $set: { publicKey: req.body.publicKey } },
          { $set: true }
        );
        return res.send(user);
      } else {
        return res.send(existingUser);
      }
    } catch (err) {
      console.log(err, "Error");
    }
  });
  app.patch("/api/addUserRewardToken", async (req, res) => {
    try {
      let rewardStatus = req.body.rewardStatus;
      const existingUser = await User.findOneAndUpdate(
        {
          publicKey: req.body.publicKey,
        },
        { $push: { rewardStatus } }
      );
      if (!existingUser) {
        res.send("User Not Found");
      } else {
        res.send(existingUser.rewardStatus);
      }
    } catch (err) {
      console.log(err, "Error");
    }
  });

  app.patch("/api/updateRewardStatus", async (req, res) => {
    try {
      let tweetId = req.body.tweetId;
      const userStatusUpdated = await User.findOneAndUpdate(
        // {
        //   "rewardStatus.tweetId": tweetId,
        // },
        {
          rewardStatus: { $elemMatch: { tweetId: tweetId } },
        },
        {
          $set: {
            "rewardStatus.$.isRewardpaid": true,
          },
        },
        {
          new: true,
        }
      );
      if (!userStatusUpdated) {
        res.send("User Not Found");
      } else {
        res.send(userStatusUpdated);
      }
    } catch (err) {
      console.log(err, "Error");
    }
  });
};
